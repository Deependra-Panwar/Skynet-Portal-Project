﻿CREATE TABLE [dbo].[registration]
(
	[Id] INT NOT NULL , 
    [first_name] NCHAR(15) NOT NULL, 
    [last_name] NCHAR(15) NULL, 
    [username] UNIQUEIDENTIFIER NOT NULL, 
    [email] NCHAR(15) NOT NULL, 
    [phone] BIGINT NULL, 
    [city] VARBINARY(20) NULL, 
    [password] VARCHAR(20) NOT NULL, 
    [images] IMAGE NULL, 
    PRIMARY KEY ([Id])
)

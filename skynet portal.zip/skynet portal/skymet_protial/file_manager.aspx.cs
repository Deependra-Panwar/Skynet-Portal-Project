﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Security;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Configuration;
public partial class file_manager : System.Web.UI.Page
{
    string qry, qry1;
    SqlConnection con;
    string first, last, img;
    string first_name, last_name, images;
    String sesion_id;
    int filsize;
    SqlDataAdapter da;
    DataSet ds;
    String now = DateTime.Now.ToString("yyyy-MM-dd");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["id"]== null)
        {
            Response.Redirect("login.aspx");
        }
        else
        {
            String sesion_id = Session["id"].ToString();
            if (!IsPostBack)
            {
                SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\deep\Documents\demo.mdf;Integrated Security=True;Connect Timeout=30");
                String str = "select * from file_manager where file_uploader=@session_id";
                SqlCommand cmd = new SqlCommand(str,conn);
                cmd.Parameters.AddWithValue("@session_id",sesion_id);
                conn.Open();
                this.DataList1.DataSource = cmd.ExecuteReader();
                this.DataList1.DataBind();
                Button2.Visible = false;
            }
        }
        send_file();
        value_geter();
    }
    protected void upload_file_Click(object sender, System.EventArgs e)
    {
         file_upload();
    }
    protected void file_upload()
    {
            
        if (FileUpload1.HasFile == true)
        {
            string filename = Path.GetFileName(FileUpload1.PostedFile.FileName);
            int filsize = FileUpload1.PostedFile.ContentLength;
            Response.Write(filsize);
            String tye =FileUpload1.PostedFile.ContentType;
            if(filsize>1024)
            {
                filsize=(filsize/ 1024);
            }
          /*   if (tye == "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
             {
                 Image1.ImageUrl = "~/pictures/docx.png";
             }
             else if (tye == "pptx")
             {
                 Image1.ImageUrl = "~/pictures/pptx.png";
             }
             else if (tye == "application/pdf")
             {
                 Image1.ImageUrl = "~/pictures/pdf.png";
             }
             else if (tye == "images")
             {
                 Image1.ImageUrl = "~/pictures/image.png";
             }
             else if (tye == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
             {
                 Image1.ImageUrl = "~/pictures/image.png";
             }
             else if (tye == "application/msaccess")
             {
                 Image1.ImageUrl = "~/pictures/image.png";
             }
             else
             {
                 Image1.ImageUrl = "~/pictures/txt.png";
             }*/

        }
        else
        {
            Response.Write("<script>alert('Username already taken...please change your username !')</script>");
        }

        try
        {
            using (Stream fs = FileUpload1.PostedFile.InputStream)
            {
                using (BinaryReader br = new BinaryReader(fs))
                {
                    byte[] bytes = br.ReadBytes((Int32)fs.Length);
                    string constr = ConfigurationManager.ConnectionStrings["skymet"].ConnectionString;
                    using (SqlConnection con = new SqlConnection(constr))
                    {
                        String sesion_id = Session["id"].ToString();
                        string file_name = filsize.ToString();
                        Response.Write(file_name);
                        FileUpload1.SaveAs(Server.MapPath("~/files_manager/" + FileUpload1.FileName));
                        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\deep\Documents\demo.mdf;Integrated Security=True;Connect Timeout=30");
                        String query = "insert into file_manager(file_name,file_size,file_date,file_uploader) values(@fil_name,@fil_size,@fil_date,@session_id)";
                        SqlCommand cmd = new SqlCommand(query, conn);
                        cmd.Parameters.AddWithValue("@fil_name", FileUpload1.PostedFile.FileName);
                        cmd.Parameters.AddWithValue("@fil_size", file_name);
                        cmd.Parameters.AddWithValue("@fil_date", now);
                        cmd.Parameters.AddWithValue("@session_id",sesion_id);
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        conn.Close();
                        Response.Redirect(Request.Url.AbsoluteUri);
                        Response.Redirect(Request.RawUrl, true);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('File Name is Too large !')</script>");
        }
    }
    public void DownloadFile(object sender, EventArgs e)
    {
        int id = int.Parse((sender as LinkButton).CommandArgument);
        byte[] bytes;
        string fileName, contentType;
        string constr = ConfigurationManager.ConnectionStrings["skymet"].ConnectionString;
        using (SqlConnection con = new SqlConnection(constr))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "select file_name,file_size,file_date,file_sender from file_manager where file_id=@Id";
                cmd.Parameters.AddWithValue("@Id",id);
                cmd.Connection = con;
                con.Open();
                using (SqlDataReader sdr = cmd.ExecuteReader())
                {
                    sdr.Read();
                    contentType = sdr["file_date"].ToString();
                    fileName = sdr["file_name"].ToString();
                    sender = sdr["file_sender"].ToString();
                }
                con.Close();
            }
        }
        Response.Clear();
        Response.Buffer = true;
        Response.Charset = "";
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.ContentType = contentType;
        Response.AppendHeader("Content-Disposition", "attachment; filename=" + fileName);
        Response.TransmitFile(Server.MapPath("~/files_manager/" + fileName));
        Response.End();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Session.RemoveAll();
        Response.Redirect("login.aspx");
    }
    protected void delete_file(object sender, EventArgs e)
    {
        int idd = int.Parse((sender as LinkButton).CommandArgument);
        String cool = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\deep\Documents\demo.mdf;Integrated Security=True;Connect Timeout=30";
        SqlConnection conn = new SqlConnection(cool);
        String del = "delete from file_manager where file_id=@Id";
        SqlCommand cmd = new SqlCommand(del, conn);
        cmd.Parameters.AddWithValue("@Id", idd);
        foreach (DataListItem item in DataList1.Items)
        {
            CheckBox lnk = (CheckBox)item.FindControl("chk");
            if (lnk.Checked == true)
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                Response.Write("<script>alert('Delete Successfully !')</script>");
            }
            else
            {
                Response.Write(" nhi pocha");
            }
        }
    }
    public void search_box()
    {
                SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\deep\Documents\demo.mdf;Integrated Security=True;Connect Timeout=30");
                String str = "select * from file_manager where file_name=@session_id";
                SqlCommand cmd = new SqlCommand(str,conn);
                cmd.Parameters.AddWithValue("@session_id",TextBox1.Text);
                conn.Open();
                this.DataList1.DataSource = cmd.ExecuteReader();
                this.DataList1.DataBind();
                conn.Close();
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        search_box();
    }
    protected void send_file()
    {
        String sesion_id = Session["id"].ToString();
        con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\deep\Documents\demo.mdf;Integrated Security=True;Connect Timeout=30");
        qry = "select first_name,last_name,images from registration where username=@session_id";
        SqlCommand cmd = new SqlCommand(qry, con);
        cmd.Parameters.AddWithValue("@session_id", sesion_id);
        con.Open();
        using (SqlDataReader sdr = cmd.ExecuteReader())
        {
            sdr.Read();
            first_name = sdr["first_name"].ToString();
            last_name = sdr["last_name"].ToString();
            images = sdr["images"].ToString();
        }
        Label7.Text = string.Concat(first_name, ' ', last_name);
        String qry1 = "select first_name,last_name,username,images from registration where u_are='student' order by first_name";
        da = new SqlDataAdapter(qry1, con);
        ds = new DataSet();
        da.Fill(ds);
        DataList2.DataSource = ds.Tables[0];
        DataList2.DataBind();
        con.Close();
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\deep\Documents\demo.mdf;Integrated Security=True;Connect Timeout=30");
        String query = "insert into file_manager(file_name,file_date,file_sender) values(@fil_name,@fil_size,@fil_date,@file_sender";
        SqlCommand cmd = new SqlCommand(query, conn);
        cmd.Parameters.AddWithValue("@fil_name", FileUpload1.PostedFile.FileName);
        cmd.Parameters.AddWithValue("@fil_date",now);
        cmd.Parameters.AddWithValue("@file_sender", sesion_id);
        foreach (DataListItem item in DataList1.Items)
        {
            CheckBox lnk = (CheckBox)item.FindControl("chk");
            if (lnk.Checked == true)
            {
                foreach (DataListItem items in DataList2.Items)
                {
                    CheckBox lnk1 = (CheckBox)items.FindControl("chk_name");
                    if (lnk1.Checked==true)
                    {
                        //conn.Open();
                        //cmd.ExecuteNonQuery();
                        //conn.Close();
                        
                    }
                }
                Response.Write("<script>alert('Send File Successfully!')</script>");
            }
            else
            {
                Response.Write("<script>alert('Please Select File to Send!')</script>");
            }
        }

    }

    public void button_close()
    {
        Response.Write("close ho rah h");
    }
    public void value_geter()
    {
        String sesion_id = Session["id"].ToString();
        con.Open();
        string user = "select first_name,last_name,images from registration where username=@session_id ";
        SqlCommand comd = new SqlCommand(user, con);
        comd.Parameters.AddWithValue("@session_id", sesion_id);
        SqlDataReader rd = comd.ExecuteReader();
        while (rd.Read())
        {
            first = rd["first_name"].ToString();
            last = rd["last_name"].ToString();
            img = rd["images"].ToString();
        }
        Image4.ImageUrl = img;
        Label9.Text = string.Concat(first, ' ', last);
        con.Close();
    }
}
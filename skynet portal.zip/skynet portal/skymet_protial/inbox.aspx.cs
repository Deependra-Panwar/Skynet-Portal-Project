﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Security;
using System.Web.Services;
using System.Web.UI.WebControls.WebParts;
using System.Web.Script.Services;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Configuration;
public partial class Default3 : System.Web.UI.Page
{
    SqlConnection conn;
    String qry;
    String str;
    string first, last, img;
    SqlDataAdapter da;
    DataSet ds;
    DateTime now = DateTime.Now;
    string name;

    public void Page_Load(object sender, EventArgs e)
    {
        if (Session["id"] == null)
        {
            Response.Redirect("login.aspx");
        }
        noticeboard();
         value_geter();
    }  
    protected void buttton4(object sender, EventArgs e)
    {

        String sesion_id = Session["id"].ToString();
 
        try
        {
            String cool = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\deep\Documents\demo.mdf;Integrated Security=True;Connect Timeout=30";
            SqlConnection conn = new SqlConnection(cool);
            conn.Open();
            String query = "insert into Messages(sender_by,sender_to,time_date,message) values (@sender_by,@sender_to,@time_date,@message)";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@message", TextBox2.Text);
            cmd.Parameters.AddWithValue("@sender_by", sesion_id);
            cmd.Parameters.AddWithValue("@time_date", now);
            cmd.Parameters.AddWithValue("@sender_to",Label1.Text);
            if (TextBox2.Text != "")
            {
                cmd.ExecuteNonQuery();
                Response.Write("<script>alert('Message Send!')</script>");
                TextBox2.Text = "";
                conn.Close();
            }
            else
            {
                Response.Write("<script>alert('Empty Message not Send!')</script>");
            }
        }
        catch(Exception ex)
        {
            Response.Write("<script>alert('Message length not greater than 50 character !')</script>");
        }
    }
                                                                             // noticeboard
    public void noticeboard()
    {
        String sesion_id = Session["id"].ToString();
        String cool = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\deep\Documents\demo.mdf;Integrated Security=True;Connect Timeout=30";
        SqlConnection conn = new SqlConnection(cool);
        str = "select sender_by from Messages where sender_to='" + sesion_id + "' union  select sender_to from Messages where sender_by='" + sesion_id + "';";
        conn.Open();
        da = new SqlDataAdapter(str,conn);
        ds = new DataSet();
        da.Fill(ds);
        DataList1.DataSource = ds.Tables[0];
        DataList1.DataBind();
        conn.Close();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Session.RemoveAll();
        Response.Redirect("login.aspx");
    }
    public void openchat(object sender,EventArgs e)
    {
        string name = (sender as LinkButton).CommandArgument;
        Label1.Text = name;
        String cool = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\deep\Documents\demo.mdf;Integrated Security=True;Connect Timeout=30";
        SqlConnection conn = new SqlConnection(cool);
        String sesion_id = Session["id"].ToString();
        qry ="select sender_by,message from Messages where(sender_by='" + sesion_id + "' and sender_to='" + name + "')or(sender_by='" + name + "' and sender_to='" + sesion_id + "') order by time_date ";
        conn.Open();
        da = new SqlDataAdapter(qry, conn);
        ds = new DataSet();
        da.Fill(ds);
        DataList2.DataSource = ds.Tables[0];
        DataList2.DataBind();
        conn.Close(); 
          
    }
    public void value_geter()
    {
        String sesion_id = Session["id"].ToString();
        String cool = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\deep\Documents\demo.mdf;Integrated Security=True;Connect Timeout=30";
        SqlConnection conn = new SqlConnection(cool);
        conn.Open();
        string user = "select first_name,last_name,images from registration where username=@session_id ";
        SqlCommand comd = new SqlCommand(user, conn);
        comd.Parameters.AddWithValue("@session_id", sesion_id);
        SqlDataReader rd = comd.ExecuteReader();
        while (rd.Read())
        {
             first = rd["first_name"].ToString();
             last = rd["last_name"].ToString();
             img = rd["images"].ToString();
        }
        Image2.ImageUrl = img;
        Label8.Text = string.Concat(first, ' ', last);
        conn.Close();
    }
    public void openchat_upload(object sender, EventArgs e)
    {

        String cool = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\deep\Documents\demo.mdf;Integrated Security=True;Connect Timeout=30";
        SqlConnection conn = new SqlConnection(cool);
        String sesion_id = Session["id"].ToString();
        string name = Label1.Text;
        qry = "select sender_by,message from Messages where(sender_by='" + sesion_id + "' and sender_to='" + name + "')or(sender_by='" + name + "' and sender_to='" + sesion_id + "') order by time_date ";
        conn.Open();
        da = new SqlDataAdapter(qry, conn);
        ds = new DataSet();
        da.Fill(ds);
        DataList2.DataSource = ds.Tables[0];
        DataList2.DataBind();
        conn.Close();
    }
    protected void Button2_Click1(object sender, EventArgs e)
    {
        string user_name;
        String sesion_id = Session["id"].ToString();
        String cool = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\deep\Documents\demo.mdf;Integrated Security=True;Connect Timeout=30";
        SqlConnection conn = new SqlConnection(cool);
        qry = "select username from registration where username=@uname";
        SqlCommand cmd = new SqlCommand(qry,conn);
        cmd.Parameters.AddWithValue("@uname", TextBox3.Text.Trim());
        SqlDataAdapter da = new SqlDataAdapter();
        da.SelectCommand = cmd;
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            user_name = ds.Tables[0].Rows[0]["username"].ToString();
            if (user_name != sesion_id)
            {
                Label1.Text = user_name;
            }
            else
            {
                Response.Write("<script>alert('you can't send message to self')</script>");
            }
        }
        else
        {
            Response.Write("<script>alert('Your Username is Not Valid!! Enter a vaild username for message')</script>");

        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        String sesion_id = Session["id"].ToString();
        string user = Label1.Text;
        String cool = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\deep\Documents\demo.mdf;Integrated Security=True;Connect Timeout=30";
        SqlConnection conn = new SqlConnection(cool);
        String del = "delete from Messages where(sender_by='" + sesion_id + "' and sender_to='" + user + "')or(sender_by='" + user + "' and sender_to='" + sesion_id + "')";
        SqlCommand cmd = new SqlCommand(del, conn);
        {
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            Response.Write("<script>alert('Delete successfully')</script>");
        }
    }
}
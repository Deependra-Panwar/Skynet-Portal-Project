﻿using System;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Net;
using System.Net.Mail;
using System.Drawing;
using System.Collections.Generic;
using System.Linq;
public partial class Default2 : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\deep\Documents\demo.mdf;Integrated Security=True;Connect Timeout=30");
    protected void Page_Load(object sender, EventArgs e)
    {
          
    }
                                                  /* LOGIN button click*/
    protected void Button1_Click1(object sender, EventArgs e)
    {
        String query = "select * from registration where username='" + TextBox1.Text + "' and password='" + TextBox2.Text + "' ";
        SqlCommand cmd = new SqlCommand(query, con);
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            Session["id"] = TextBox1.Text;
            Response.Redirect("Dashboard.aspx");
        }
        else
        {
            Response.Write("<script>alert('Enter Invaild Username and Password!')</script>");
            TextBox1.Text = "";
            TextBox2.Text = "";
        }

    }
                                                    /* Send mail click*/
    protected void SendEmail(object sender, EventArgs e)
    {
       string password = string.Empty;
        string qry;
        String cool = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\deep\Documents\demo.mdf;Integrated Security=True;Connect Timeout=30";
        SqlConnection conn = new SqlConnection(cool);
        conn.Open();
        qry = "select password from registration where username=@username and email=@email";
        SqlCommand cmd = new SqlCommand(qry, conn);
        cmd.Parameters.AddWithValue("@username", TextBox3.Text.Trim());
        cmd.Parameters.AddWithValue("@email", TextBox4.Text.Trim());   
        SqlDataAdapter da = new SqlDataAdapter();
        da.SelectCommand = cmd;
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            password = ds.Tables[0].Rows[0]["password"].ToString();
            sendpassword(password, TextBox3.Text);
            Response.Write("<script>alert('Your Password Has Been Sent to Registered Email Address. Check Your Mail Inbox')</script>");
        }
        else
        {
            Response.Write("<script>alert('Your Username is Not Valid or Email Not Registered')</script>");

        }
        con.Close();

    }
    private void sendpassword(String password, String email)
    {
        SmtpClient smtp = new SmtpClient();
        smtp.Host = "smtp.gmail.com";
        smtp.Port = 587;
        smtp.Credentials = new System.Net.NetworkCredential("658varshasharma@gmail.com", "varsha@123..");
        smtp.EnableSsl = true;
        MailMessage msg = new MailMessage();
        msg.Subject = "Forgot Password ( Skynet Portal )";
        msg.Body = "Dear " + TextBox3.Text + ", Your Password is  " + password + "\n\n\nThanks & Regards\nSkynet Portal Team";
        string toaddress = TextBox4.Text;
        msg.To.Add(toaddress);
        string fromaddress = "Skynet Portal <658varshasharma@gmail.com>";
        msg.From = new MailAddress(fromaddress);
        try
        {
            smtp.Send(msg);


        }
        catch
        {
            throw;
        }
    }


}
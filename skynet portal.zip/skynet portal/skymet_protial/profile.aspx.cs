﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
public partial class profile : System.Web.UI.Page
{
    string qry,qry1;
    SqlConnection con;
    DateTime now = DateTime.Now;
    string first, last, img;
    string first_name,last_name,email,phone,city,images,pass,created_on,last_acess,last_update;
    String sesion_id;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["id"] == null)
        {
            Response.Redirect("login.aspx");
        }
        if (!IsPostBack)
        {
            String sesion_id = Session["id"].ToString();
            con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\deep\Documents\demo.mdf;Integrated Security=True;Connect Timeout=30");
            qry = "select registration.first_name,registration.last_name,registration.email,registration.phone,registration.city,registration.password,registration.images,login.last_access,login.last_profile_update from registration inner join login on registration.username=@session_id";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@session_id", sesion_id);
            con.Open();
            using (SqlDataReader sdr = cmd.ExecuteReader())
            {
                while (sdr.Read())
                {
                    first_name = sdr["first_name"].ToString();
                    last_name = sdr["last_name"].ToString();
                    email = sdr["email"].ToString();
                    phone = sdr["phone"].ToString();
                    city = sdr["city"].ToString();
                    images = sdr["images"].ToString();
                    last_update = sdr["last_profile_update"].ToString();
                    created_on = sdr["images"].ToString();
                    last_acess = sdr["last_access"].ToString();
                    pass = sdr["password"].ToString();
                }
            }
            con.Close();
            Label9.Text = string.Concat(first_name, ' ', last_name);
            Label10.Text = email;
            Image1.ImageUrl = images;
            Label8.Text = last_update;
            Label5.Text = last_acess;
            TextBox1.Text = first_name;
            TextBox2.Text = last_name;
             TextBox3.Text = sesion_id;
            TextBox4.Text = email;
            TextBox5.Text = phone;
            value_geter();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
         if (TextBox6.Text==pass)
            {
                String sesion_id = Session["id"].ToString();
                con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\deep\Documents\demo.mdf;Integrated Security=True;Connect Timeout=30");
                con.Open();
                qry1 = "update registration SET first_name='" + TextBox1.Text + "',last_name='" + TextBox2.Text + "',email='" + TextBox4.Text + "',phone='" + TextBox5.Text + "' where username=@session_id";
                SqlCommand cmd = new SqlCommand(qry1, con);
                cmd.Parameters.AddWithValue("@session_id", sesion_id);
                cmd.ExecuteNonQuery();
                SqlCommand cmdd = new SqlCommand(qry1, con);
                cmdd.Parameters.AddWithValue("@session_id",now);
                cmdd.ExecuteNonQuery();
                con.Close();
                Response.Write("<script>alert('Update Successfully!')</script>");
           }
            else
            {
                Response.Write("<script>alert('Password is incorrect !')</script>");
            }
        }
    protected void Button2_Click(object sender, EventArgs e)
    {
        if (TextBox7.Text == pass)
        {
            con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\deep\Documents\demo.mdf;Integrated Security=True;Connect Timeout=30");
            con.Open();
            qry1 = "update registration SET password='" + TextBox9.Text + "' where username=@session_id";
            SqlCommand cmd = new SqlCommand(qry1, con);
            cmd.Parameters.AddWithValue("@session_id", sesion_id);
            cmd.ExecuteNonQuery();
            con.Close();
            Response.Write("<script>alert('Change Password successfully!')</script>");
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Session.RemoveAll();
        Response.Redirect("login.aspx");
    }
    public void value_geter()
    {
        String sesion_id = Session["id"].ToString();
        String cool = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\deep\Documents\demo.mdf;Integrated Security=True;Connect Timeout=30";
        SqlConnection conn = new SqlConnection(cool);
        conn.Open();
        string user = "select first_name,last_name,images from registration where username=@session_id ";
        SqlCommand comd = new SqlCommand(user, conn);
        comd.Parameters.AddWithValue("@session_id", sesion_id);
        SqlDataReader rd = comd.ExecuteReader();
        while (rd.Read())
        {
            first = rd["first_name"].ToString();
            last = rd["last_name"].ToString();
            img = rd["images"].ToString();
        }
        Image2.ImageUrl = img;
        Label11.Text = string.Concat(first, ' ', last);
        conn.Close();
    }
} 
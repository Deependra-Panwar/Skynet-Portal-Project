﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Dashboard : System.Web.UI.Page
{
    String qry;
    String qry1;
    String user;
    string first,last,images,img,check;
    string first_name, last_name, email, phone, city, imagess, created_on, last_access;
    SqlConnection con;
    SqlDataAdapter da,daa;
    DataSet ds,dss;
    String now =DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss");
   
    public void Page_Load(object sender, EventArgs e)
    {
        Button5.Visible = false;
        Label5.Text = Application["OnlineUsers"].ToString();      
        if (Session["id"]== null)
        {
            Response.Redirect("login.aspx");
        }
        else
        {
           
           con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\deep\Documents\demo.mdf;Integrated Security=True;Connect Timeout=30");
           noticeboard();
           std_list();
           value_geter();
           checkadmin();
           tech_list();          
        }
        
    }   
    protected void Button2_Click(object sender, EventArgs e)
    {
        Session.RemoveAll();
        Response.Redirect("login.aspx");
        
    }
    public void noticeboard()
    {
        qry = "select registration.first_name,registration.images,event_list.event_name,event_list.held_date,event_list.location_at from registration inner join event_list on registration.username=event_list.session_id order by event_list.held_date";
        da= new SqlDataAdapter((qry),con);
        ds = new DataSet();
        da.Fill(ds);
        DataList1.DataSource = ds.Tables[0];
        DataList1.DataBind();
            
    }
    public void value_geter()
    {
        String sesion_id = Session["id"].ToString();
        con.Open();
        user = "select first_name,last_name,images from registration where username=@session_id ";
        SqlCommand comd = new SqlCommand(user, con);
        comd.Parameters.AddWithValue("@session_id",sesion_id);
        SqlDataReader rd=comd.ExecuteReader();
        while (rd.Read())
        {
            first = rd["first_name"].ToString();
            last = rd["last_name"].ToString();
            images = rd["images"].ToString();
        }
        con.Close();
        Image2.ImageUrl = images;
        Label8.Text=string.Concat(first, ' ', last);
    }
    

    protected void Button1_Click(object sender, EventArgs e)
    {
        String sesion_id = Session["id"].ToString();
        try
        {
            
                con.Open();
                String query = "insert into event_list(session_id,event_name,location_at,held_date) values (@session_id,@event,@location,@date_time)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@session_id", sesion_id);
                cmd.Parameters.AddWithValue("@event", TextBox1.Text);
                cmd.Parameters.AddWithValue("@location", TextBox2.Text);
                cmd.Parameters.AddWithValue("@date_time", now);
                cmd.ExecuteNonQuery();
                Response.Write("event Created");
                con.Close();
            
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('Please Fill location and event field properly !')</script>");
        }
    }
    protected void std_list()
    {
        con.Open();
        qry = "select * from registration where u_are='student'";
        daa = new SqlDataAdapter(qry, con);
        dss = new DataSet();
        daa.Fill(dss);
        DataList3.DataSource = dss.Tables[0];
        DataList3.DataBind();
        con.Close();
    }

    protected void tech_list()
    {
        con.Open();
        qry = "select * from registration where u_are='teacher'";
        daa = new SqlDataAdapter(qry, con);
        dss = new DataSet();
        daa.Fill(dss);
        DataList4.DataSource = dss.Tables[0];
        DataList4.DataBind();
        con.Close();
    }
    public void tech_profile()
    {
        string u_name = "Sumitp";
        con.Open();
        qry = "select registration.first_name,registration.last_name,registration.email,registration.phone,registration.city,registration.images,login.last_access from registration inner join login on registration.username=@u_name";
        SqlCommand cmd = new SqlCommand(qry, con);
        cmd.Parameters.AddWithValue("@u_name", u_name);
        using (SqlDataReader sdr = cmd.ExecuteReader())
        {
            while (sdr.Read())
            {
                first_name = sdr["first_name"].ToString();
                last_name = sdr["last_name"].ToString();
                email = sdr["email"].ToString();
                phone = sdr["phone"].ToString();
                city = sdr["city"].ToString();
                imagess = sdr["images"].ToString();
                created_on = sdr["images"].ToString();
                last_access = sdr["last_access"].ToString();
            }
        }
        con.Close();
        Label9.Text = string.Concat(first_name, ' ', last_name);
        Image1.ImageUrl = imagess;
        Label10.Text = email;
        Label12.Text = city;
        Label13.Text = phone;
        Label2.Text = created_on;
        Label6.Text = last_access;
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        Response.Redirect("Admin.aspx");
    }
    public void checkadmin()
    {
        String sesion_id = Session["id"].ToString();
        con.Open();
        qry = "select u_are from registration where username=@u_name";
        SqlCommand cmd = new SqlCommand(qry, con);
        cmd.Parameters.AddWithValue("@u_name",sesion_id);
        using (SqlDataReader sdr = cmd.ExecuteReader())
        {
            while (sdr.Read())
            {
                check = sdr["u_are"].ToString();
            }
        }
        if (check == "teacher   ")
        {
            this.Button5.Visible = true;
        }
        con.Close();
    }
}
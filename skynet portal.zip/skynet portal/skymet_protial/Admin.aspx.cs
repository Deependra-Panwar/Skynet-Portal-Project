﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Admin : System.Web.UI.Page
{
    String qry,password;
    String qry1;
    String user;
    string first_name, last_name, email, phone, city, images, pass, created_on, last_acess, last_update;
    string first,last,img;
    SqlConnection con;
    SqlDataAdapter da, daa;
    DataSet ds, dss;
    String now = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss");
    protected void Page_Load(object sender, EventArgs e)
    {
        Label5.Text = Application["OnlineUsers"].ToString();
        if (Session["id"] == null)
        {
            Response.Redirect("login.aspx");
        }
        else
        {
            con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\deep\Documents\demo.mdf;Integrated Security=True;Connect Timeout=30");
            con.Open();
            con.Close();
            std_list();
            value_geter();
            tech_list();
           
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Session.RemoveAll();
        Response.Redirect("login.aspx");

    }
     public void value_geter()
    {
        String sesion_id = Session["id"].ToString();
        con.Open();
        user = "select first_name,last_name,images from registration where username=@session_id ";
        SqlCommand comd = new SqlCommand(user, con);
        comd.Parameters.AddWithValue("@session_id",sesion_id);
        SqlDataReader rd=comd.ExecuteReader();
        while (rd.Read())
        {
            first = rd["first_name"].ToString();
            last= rd["last_name"].ToString();
            img= rd["images"].ToString();
        }
        Image4.ImageUrl = img;
        Label8.Text = string.Concat(first, ' ', last);
        con.Close();
    }


    protected void Button1_Click(object sender, EventArgs e)
    {
        string qry;
        String cool = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\deep\Documents\demo.mdf;Integrated Security=True;Connect Timeout=30";
        SqlConnection conn = new SqlConnection(cool);
        conn.Open();
        qry = "select password from registration where username=@username and email=@email";
        SqlCommand cmd = new SqlCommand(qry, conn);
        cmd.Parameters.AddWithValue("@username", TextBox1.Text);
        cmd.Parameters.AddWithValue("@email", TextBox2.Text);   
        SqlDataAdapter da = new SqlDataAdapter();
        da.SelectCommand = cmd;
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            password = ds.Tables[0].Rows[0]["password"].ToString();
            Label15.Text = password;
            TextBox1.Text = "";
            TextBox2.Text = "";
        }
        else
        {
            Response.Write("<script>alert('Your Username or Not vaild')</script>");

        }
        con.Close();

 }

    protected void std_list()
    {
        con.Open();
        qry = "select * from registration where u_are='student'";
        SqlCommand cmd = new SqlCommand(qry, con);
        SqlDataReader dr = cmd.ExecuteReader();
        DataTable dt = new DataTable();
        dt.Load(dr);
        dr.Close();
        con.Close();
        Repeater2.DataSource = dt;
        Repeater2.DataBind();
    }
    protected void tech_list()
    {
        con.Open();
        qry = "select * from registration where u_are='teacher'";
        SqlCommand cmd= new SqlCommand(qry,con);
        SqlDataReader dr= cmd.ExecuteReader();
        DataTable dt= new DataTable();
        dt.Load(dr);
        dr.Close();
        con.Close();
        Repeater1.DataSource = dt;
        Repeater1.DataBind();
    }
    public void see_profile(object sender, EventArgs e)
    {
        string user = (sender as LinkButton).CommandArgument;
        string constr = ConfigurationManager.ConnectionStrings["skymet"].ConnectionString;
        using (SqlConnection con = new SqlConnection(constr))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "select registration.first_name,registration.last_name,registration.email,registration.phone,registration.images,login.last_access from registration inner join login on registration.username=@session_id";
                cmd.Parameters.AddWithValue("@Id",user);
                cmd.Connection = con;
                con.Open();
                using (SqlDataReader sdr = cmd.ExecuteReader())
                {
                    while (sdr.Read())
                    {
                        first_name = sdr["first_name"].ToString();
                        last_name = sdr["last_name"].ToString();
                        email = sdr["email"].ToString();
                        phone = sdr["phone"].ToString();
                        images = sdr["images"].ToString();
                        created_on = sdr["images"].ToString();
                        last_acess = sdr["last_access"].ToString();
                    }
                }
                Image1.ImageUrl=images;
                Label10.Text = email;
                Label13.Text =string.Concat(first_name, ' ', last_name);
                Label14.Text=phone;
                Label2.Text=created_on;
                Label6.Text=last_acess;
                con.Close();
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Security;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Configuration;

public partial class upload_result : System.Web.UI.Page
{
    SqlConnection conn;
    String qry,check;
    String str;
    SqlDataAdapter da;
    DataSet ds;
    string first, last, img;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["id"] == null)
        {
            Response.Redirect("login.aspx");
        }
        else
        {
            FileUpload1.Enabled = false;
            TextBox1.Enabled = false;
            TextBox2.Enabled = false;
            TextBox3.Enabled = false;
            DropDownList1.Enabled = false;
            DropDownList4.Enabled = false;
            DropDownList5.Enabled = false;
            Button3.Enabled = false;
            noticeboard();
            value_geter();
            checkadmin();
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Session.RemoveAll();
        Response.Redirect("login.aspx");
    }
    public void noticeboard()
    {
        String cool = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\deep\Documents\demo.mdf;Integrated Security=True;Connect Timeout=30";
        SqlConnection conn = new SqlConnection(cool);
        conn.Open();
        str = "select * from result";
        da = new SqlDataAdapter(str, conn);
        ds = new DataSet();
        da.Fill(ds);
        DataList1.DataSource = ds.Tables[0];
        DataList1.DataBind();
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        string abc = DropDownList1.SelectedItem.ToString();
        string val = DropDownList1.SelectedItem.ToString();
        string batch = DropDownList5.SelectedItem.ToString();
        string std_class = DropDownList4.SelectedItem.ToString();
        using (Stream fs = FileUpload1.PostedFile.InputStream)
        {
            using (BinaryReader br = new BinaryReader(fs))
            {
                byte[] bytes = br.ReadBytes((Int32)fs.Length);
                string constr = ConfigurationManager.ConnectionStrings["skymet"].ConnectionString;
                using (SqlConnection con = new SqlConnection(constr))
                {

                    String sesion_id = Session["id"].ToString();
                    DateTime now = DateTime.Now;
                    FileUpload1.SaveAs(Server.MapPath("~/result/" + FileUpload1.FileName));
                    SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\deep\Documents\demo.mdf;Integrated Security=True;Connect Timeout=30");
                    String query = "insert into result(sub_name,sub_code,batch,class,exam_type,announced_date,file_name) values(@sub_name,@sub_code,@batch,@class,@exam_type,@announced_date,@fil_name)";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@sub_name", TextBox1.Text);
                    cmd.Parameters.AddWithValue("@sub_code", TextBox2.Text);
                    cmd.Parameters.AddWithValue("@batch", batch);
                    cmd.Parameters.AddWithValue("@class", std_class);
                    cmd.Parameters.AddWithValue("@exam_type", val);
                    cmd.Parameters.AddWithValue("@announced_date", now);
                    cmd.Parameters.AddWithValue("@fil_name", FileUpload1.PostedFile.FileName);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    Response.Write("<script>alert('Result upload succesfully !')</script>");
                    Response.Redirect(Request.Url.AbsoluteUri);
                    Response.Redirect(Request.RawUrl, true);
                }
            }
        }
    }
    public void DownloadFile(object sender, EventArgs e)
    {
        int id = int.Parse((sender as LinkButton).CommandArgument);
        string fileName, contentType;
        string constr = ConfigurationManager.ConnectionStrings["skymet"].ConnectionString;
        using (SqlConnection con = new SqlConnection(constr))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "select sub_name,file_name,announced_date from result where id=@Id";
                cmd.Parameters.AddWithValue("@Id",id);
                cmd.Connection = con;
                con.Open();
                using (SqlDataReader sdr = cmd.ExecuteReader())
                {
                    sdr.Read();
                    contentType = sdr["sub_name"].ToString();
                    fileName = sdr["file_name"].ToString();
                    sender = sdr["announced_date"].ToString();
                }
                con.Close();
            }
        }
        Response.Clear();
        Response.Buffer = true;
        Response.Charset = "";
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.ContentType = contentType;
        Response.AppendHeader("Content-Disposition", "attachment; filename=" + fileName);
        Response.TransmitFile(Server.MapPath("~/result/" + fileName));
        Response.End();
    }
    public void value_geter()
    {
        String cool = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\deep\Documents\demo.mdf;Integrated Security=True;Connect Timeout=30";
        SqlConnection conn = new SqlConnection(cool);
        String sesion_id = Session["id"].ToString();
        conn.Open();
       string user = "select first_name,last_name,images from registration where username=@session_id ";
        SqlCommand comd = new SqlCommand(user, conn);
        comd.Parameters.AddWithValue("@session_id", sesion_id);
        SqlDataReader rd = comd.ExecuteReader();
        while (rd.Read())
        {
            first = rd["first_name"].ToString();
            last = rd["last_name"].ToString();
            img = rd["images"].ToString();
        }
        Image1.ImageUrl = img;
        Label7.Text = string.Concat(first, ' ', last);
        conn.Close();
    }
    public void checkadmin()
    {
        String sesion_id = Session["id"].ToString();
        String cool = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\deep\Documents\demo.mdf;Integrated Security=True;Connect Timeout=30";
        SqlConnection conn = new SqlConnection(cool);
        conn.Open();
        qry = "select u_are from registration where username=@u_name";
        SqlCommand cmd = new SqlCommand(qry, conn);
        cmd.Parameters.AddWithValue("@u_name", sesion_id);
        using (SqlDataReader sdr = cmd.ExecuteReader())
        {
            while (sdr.Read())
            {
                check = sdr["u_are"].ToString();
            }
        }
        if (check == "teacher   ")
        {
            FileUpload1.Enabled = true;
            TextBox1.Enabled = true;
            TextBox2.Enabled = true;
            TextBox3.Enabled = true;
            DropDownList1.Enabled = true;
            DropDownList4.Enabled = true;
            DropDownList5.Enabled = true;
            Button3.Enabled = true;

        }
        conn.Close();
    }
}
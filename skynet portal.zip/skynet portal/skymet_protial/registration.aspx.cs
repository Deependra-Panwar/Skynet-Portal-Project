﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class _Default : System.Web.UI.Page
{
    static String imagelink;
    DateTime now = DateTime.Now;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void submit_Click(object sender, EventArgs e)
    {
        if (uploadimage() == true)
        {
            string value = "";
            bool isChecked = student.Checked;
            if (isChecked)
                value ="student";
            else
                value ="teacher";
            try
            {

                string batch = DropDownList1.SelectedItem.ToString();
                String cool = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\deep\Documents\demo.mdf;Integrated Security=True;Connect Timeout=30";
                SqlConnection conn = new SqlConnection(cool);
                conn.Open();
                String query = "insert into registration(first_name,last_name,username,email,phone,city,password,images,u_are,batch,created_on) values (@firstname,@lastname,@usernames,@email,@phone,@city,@password,@images,@u_are,@batch,@created_on)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@firstname", TextBox1.Text);
                cmd.Parameters.AddWithValue("@lastname", TextBox2.Text);
                cmd.Parameters.AddWithValue("@usernames", TextBox3.Text);
                cmd.Parameters.AddWithValue("@email", TextBox4.Text);
                cmd.Parameters.AddWithValue("@phone", TextBox5.Text);
                cmd.Parameters.AddWithValue("@city", TextBox6.Text);
                cmd.Parameters.AddWithValue("@password", TextBox7.Text);
                cmd.Parameters.AddWithValue("@images",Image1.ImageUrl);
                cmd.Parameters.AddWithValue("@u_are",value);
                cmd.Parameters.AddWithValue("@batch",batch);
                cmd.Parameters.AddWithValue("@created_on",now);
                cmd.ExecuteNonQuery();
                Response.Write("<script>alert('Your Account Has been registered Suceesfully !')</script>");
                Response.Redirect("Login.aspx");
                conn.Close();
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('Username already taken...please change your username !')</script>");
            }
        }
    }

  public Boolean uploadimage()
    {
        Boolean imagesaved = false;
        if (FileUpload1.HasFile == true)
        {

            String contenttype = FileUpload1.PostedFile.ContentType;

            if (contenttype == "image/jpeg")
            {
                int filesize;
                filesize = FileUpload1.PostedFile.ContentLength;

                if (filesize >= 51200)
                {
                    System.Drawing.Image img = System.Drawing.Image.FromStream(FileUpload1.PostedFile.InputStream);
                    int height = img.Height;
                    int width = img.Width;
                    if (height >= 100 && width >= 100)
                    {
                        FileUpload1.SaveAs(Server.MapPath("~/img/") + TextBox1.Text + ".jpg");
                        Image1.ImageUrl = "~/img/" + TextBox1.Text + ".jpg";
                        imagelink = "img/" + TextBox1.Text + ".jpg";
                        imagesaved = true;
                    }
                    else
                    {
                        Label1.Text = "Kindly Upload JPEG Image in Proper Dimensions 100 x 100";
                    }

                }
                else
                {
                    Label1.Text = "File Size exceeds 50 KB - Please Upload File Size Maximum 50 KB";
                }

            }
            else
            {
                Label1.Text = "Only JPEG/JPG Image File Acceptable - Please Upload Image File Again";
            }
        }
        else
        {
            Label1.Text = "You have not selected any of your picture - Browse and Select File First";
        }

        return imagesaved;

    }
}